#ifndef __BH1750_H
#define __BH1750_H
#include "sys.h"


 
//#define SDA_IN()  {GPIOB->CRL&=0X0FFFFFFF;GPIOB->CRL|=(u32)8<<28;}       
//#define SDA_OUT() {GPIOB->CRL&=0X0FFFFFFF;GPIOB->CRL|=(u32)3<<28;}

#define IIC_SCL    PBout(6) //SCL
#define IIC_SDA    PBout(7) //SDA     
#define READ_SDA   PBin(7)   
#define ADDR 0x23 
#define uchar unsigned char 

#define BHAddWrite     0x46       
#define BHAddRead      0x47       
#define BHPowDown      0x00       
#define BHPowOn        0x01       
#define BHReset        0x07       
#define BHModeH1       0x10       
#define BHModeH2       0x11       
#define BHModeL        0x13       
#define BHSigModeH     0x20       
#define BHSigModeH2    0x21       
#define BHSigModeL     0x23       

 
void BH1750_Config_Init(void);
void bh_data_send(u8 command);
u16 bh_data_read(void);

 
void IIC_Sta(void);                 
void IIC_Sto(void);                   
//void IIC_Send_Byte(u8 txd);             
u8 IIC_Read_Byte(unsigned char ack); 
u8 IIC_Wait(void);                  
void IIC_Ack(void);                     
void IIC_NAck(void);                 
#endif
