/*==========================================================
DTH11��ʪ�ȴ�����ģ��
==========================================================*/

#include "DHT11.h"
//==========================================================
//	�������ƣ�	DTH11_GPIOInit()
//
//	�������ܣ�	DTH11 gpio�ڳ�ʼ��
//
//	��ڲ�����	��
//
//	���ز�����	��
//
//	˵����	PA7
//==========================================================
GPIO_InitTypeDef GPIO_InitStructure;	
 void DTH11_GPIOInit(void){

	 RCC_APB2PeriphClockCmd(DHT11_APB2PeriphRCC,ENABLE); 
	
	GPIO_InitStructure.GPIO_Pin = DHT11_PIN;           
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;  
	GPIO_InitStructure.GPIO_Speed =GPIO_Speed_50MHz;   
	GPIO_Init(DHT11_IO,&GPIO_InitStructure);
}
//����IOΪ�������ģʽ                                       
void GPIO_SETOUT(void)
{
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;  
	GPIO_Init(DHT11_IO,&GPIO_InitStructure);
	
}
//����IOΪ��������ģʽ  
void GPIO_SETIN(void)
{
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;  
	GPIO_Init(DHT11_IO,&GPIO_InitStructure);
}
//DTH11��λ����
 void DHT11_Rst(void)     
{                 
	GPIO_SETOUT();											 
	GPIO_ResetBits(DHT11_IO,DHT11_PIN);  
	delay_ms(20);    										 
	GPIO_SetBits(DHT11_IO,DHT11_PIN); 	 
	delay_us(30);     									 
	GPIO_ResetBits(DHT11_IO,DHT11_PIN);
}
//DTH11Ӧ����
 u8 DHT11_Check(void) 	   
{   
	u8 retry=0;
	GPIO_SETIN();			 
	
  while (!GPIO_ReadInputDataBit(DHT11_IO,DHT11_PIN) && retry<100) 
	{
		retry++;
		delay_us(1);
	}
	if(retry >= 100)	 
		return 0;
	else 
		retry = 0;
  while (GPIO_ReadInputDataBit(DHT11_IO,DHT11_PIN) && retry<100) 
	{
		retry++;
		delay_us(1);
	}
	if(retry>=100)		 
		return 0;
	return 1;					 
}

//DTH11��1λ��������
static u8 DHT11_Read_Bit(void)
{
 	u8 retry = 0;
	 
	while(GPIO_ReadInputDataBit(DHT11_IO,DHT11_PIN) && retry<100) 
	{
		retry++;
		delay_us(1);
	}
	retry = 0;
	while(!GPIO_ReadInputDataBit(DHT11_IO,DHT11_PIN) && retry<100) 
	{
		retry++;
		delay_us(1);
	}
	delay_us(30); 
	 
	if(GPIO_ReadInputDataBit(DHT11_IO,DHT11_PIN)) return 1;
	else return 0;		   
}
//DTH11��һ�ֽں���
static u8 DHT11_Read_Byte(void)    
{        
  u8 i,dat;
  dat=0;
	
	for (i=0;i<8;i++) 
	{
   	dat<<=1; 
	  dat|=DHT11_Read_Bit();
  }	
	
  return dat;
}
//��ȡ�¶Ⱥ�ʪ��
 u8 DHT11_Read_Data(u8 *temp,u8 *humi)
{        
 	u8 buf[5];
	u8 i;
	DHT11_Rst();
	if(DHT11_Check()==1)	 
	{
		for(i=0;i<5;i++) 
		{
			buf[i]=DHT11_Read_Byte();
		}
		if((buf[0]+buf[1]+buf[2]+buf[3])==buf[4])//�ж϶�ȡֵ�Ƿ����� 
		{
			*humi=buf[0];//ǰ8λλʪ������ֵ
			*temp=buf[2];//16��24λ�¶�����ֵ
		}
	}else return 0;		 
	return 1;					 
}
//DTH11��ʼ������
u8 DHT11_Init(void){
	 DTH11_GPIOInit();	
	DHT11_Rst(); 
	
	return DHT11_Check(); 
}

