#ifndef __PWM_OUTPUT_H
#define	__PWM_OUTPUT_H

#include "stm32f10x.h"

 extern u8 chuanglian_falg;

void TIM1_PWM_Init(void);
void Servo_out (void);
void Servo_in (void);
#endif /* __PWM_OUTPUT_H */

