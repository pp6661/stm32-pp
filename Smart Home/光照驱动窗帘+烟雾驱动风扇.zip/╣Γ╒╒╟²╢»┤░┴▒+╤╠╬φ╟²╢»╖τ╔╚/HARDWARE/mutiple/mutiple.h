#ifndef __mutiple_H
#define __mutiple_H	 
#include "sys.h"

//led
#define LED0 PBout(8)	// PB8
#define LED1 PBout(9)	// PB9
//������
#define BEEP PBout(3)
//����
#define fengshan PCout(13)

void LED_Init(void);
void Beep_Init(void);
void JDQ_Init(void);

#endif

