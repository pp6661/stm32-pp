#include "usart.h"
#include "delay.h"

#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include "LED.h"
#include "pwm_output.h"
#include "mutiple.h"
//ASPRO串口，串口1,PA9 TX PA10 RX 
void Usart1_Init(unsigned int baud)
{
  //GPIO端口设置
	GPIO_InitTypeDef gpioInitStruct;
	USART_InitTypeDef usartInitStruct;
	NVIC_InitTypeDef nvicInitStruct;
	//使能USART1，GPIOA时钟

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	
	//USART1_TX   GPIOA.9 
	gpioInitStruct.GPIO_Mode = GPIO_Mode_AF_PP;	//复用推挽输出
	gpioInitStruct.GPIO_Pin = GPIO_Pin_9; //PA.9
	gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;//初始化GPIOA.9
	GPIO_Init(GPIOA, &gpioInitStruct);
	
	 //USART1_RX	  GPIOA.10初始化
	gpioInitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;//浮空输入
	gpioInitStruct.GPIO_Pin = GPIO_Pin_10;//PA10
	GPIO_Init(GPIOA, &gpioInitStruct);//初始化GPIOA.10 
	//USART 初始化设置
	usartInitStruct.USART_BaudRate = baud;//串口波特率
	usartInitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//字长为8位数据格式	 
	usartInitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;//收发模式			 
	usartInitStruct.USART_Parity = USART_Parity_No;//无奇偶校验位									 
	usartInitStruct.USART_StopBits = USART_StopBits_1;//一个停止位									 
	usartInitStruct.USART_WordLength = USART_WordLength_8b;//字长为8位数据格式							 
	USART_Init(USART1, &usartInitStruct);//初始化串口1
	
	USART_Cmd(USART1, ENABLE); //使能串口1 														 
	
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);//开启串口接受中断									 
	//USART 初始化设置
	nvicInitStruct.NVIC_IRQChannel = USART1_IRQn;
	nvicInitStruct.NVIC_IRQChannelCmd = ENABLE;//IRQ通道使能
	nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 0;//抢占优先级0
	nvicInitStruct.NVIC_IRQChannelSubPriority = 2;//抢占优先级2
	NVIC_Init(&nvicInitStruct);		//根据指定的参数初始化VIC寄存器

}
//ESP8266串口,串口2,PA2 TX PA3 RX
void Usart2_Init(unsigned int baud)
{
  //GPIO端口设置
	GPIO_InitTypeDef gpioInitStruct;
	USART_InitTypeDef usartInitStruct;
	NVIC_InitTypeDef nvicInitStruct;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	
	//PA2
	gpioInitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
	gpioInitStruct.GPIO_Pin = GPIO_Pin_2;
	gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &gpioInitStruct);
	
	//PA3
	gpioInitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	gpioInitStruct.GPIO_Pin = GPIO_Pin_3;
	gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &gpioInitStruct);
	
	usartInitStruct.USART_BaudRate = baud;
	usartInitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;		 
	usartInitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;						 
	usartInitStruct.USART_Parity = USART_Parity_No;									 
	usartInitStruct.USART_StopBits = USART_StopBits_1;								 
	usartInitStruct.USART_WordLength = USART_WordLength_8b;							 
	USART_Init(USART2, &usartInitStruct);
	
	USART_Cmd(USART2, ENABLE);														 
	
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);									 
	
	nvicInitStruct.NVIC_IRQChannel = USART2_IRQn;
	nvicInitStruct.NVIC_IRQChannelCmd = ENABLE;
	nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 0;
	nvicInitStruct.NVIC_IRQChannelSubPriority = 0;
	NVIC_Init(&nvicInitStruct);

}
//连接云平台串口监测口,串口3,PB10 TX PB11 RX
void Usart3_Init(unsigned int baud)
{

	GPIO_InitTypeDef gpioInitStruct;
	USART_InitTypeDef usartInitStruct;
	NVIC_InitTypeDef nvicInitStruct;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
	
	//PB10 TX
	gpioInitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
	gpioInitStruct.GPIO_Pin = GPIO_Pin_10;
	gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &gpioInitStruct);
	
	//PB11 RX
	gpioInitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	gpioInitStruct.GPIO_Pin = GPIO_Pin_11;
	gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &gpioInitStruct);
	
	usartInitStruct.USART_BaudRate = baud;
	usartInitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;		 
	usartInitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;						 
	usartInitStruct.USART_Parity = USART_Parity_No;									 
	usartInitStruct.USART_StopBits = USART_StopBits_1;								 
	usartInitStruct.USART_WordLength = USART_WordLength_8b;							 
	USART_Init(USART3, &usartInitStruct);
	
	USART_Cmd(USART3, ENABLE);														 
	
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);									 
	
	nvicInitStruct.NVIC_IRQChannel = USART3_IRQn;
	nvicInitStruct.NVIC_IRQChannelCmd = ENABLE;
	nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 0;
	nvicInitStruct.NVIC_IRQChannelSubPriority = 0;
	NVIC_Init(&nvicInitStruct);

}

//==========================================================
//	函数名称：	Usart_SendString
//
//	函数功能：串口发送数据
//
//	入口参数：	USART_TypeDef *USARTx：串口号 unsigned char *str：字符串 len：字符串：长度
//
//	返回参数：	无
//
//	说明：		
//==========================================================
void Usart_SendString(USART_TypeDef *USARTx, unsigned char *str, unsigned short len)
{

	unsigned short count = 0;
	
	for(; count < len; count++)
	{
		USART_SendData(USARTx, *str++);									 
		while(USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);		 
	}

}
//串口打印数据
void UsartPrintf(USART_TypeDef *USARTx, char *fmt,...)
{

	unsigned char UsartPrintfBuf[296];
	va_list ap;//va_list初始化变量
	unsigned char *pStr = UsartPrintfBuf;
	
	va_start(ap, fmt);//返回所需参数类型
	/********************************************************************************************************************************************
	 *int vsnprintf(char *str, size_t size, const char *format, va_list ap);                                                                    *
	 *参数：str保存输出字符数组存储区。size存储区的大小。format包含格式字符串的C字符串，其格式字符串与printf中的格式相同arg变量参数列表，用va_list 定义.*	
	 ********************************************************************************************************************************************/
	vsnprintf((char *)UsartPrintfBuf, sizeof(UsartPrintfBuf), fmt, ap);							 
	va_end(ap);//清空va_list
	
	while(*pStr != 0)//串口发送数据
	{
		USART_SendData(USARTx, *pStr++);
		while(USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);
	}

}

//语音控制
extern u8 alarmFlag ; 
void USART1_IRQHandler(void)
{
 u8 res;  
 if(USART_GetITStatus(USART1,USART_IT_RXNE)!=RESET)  
 {  
  res= USART_ReceiveData(USART1); 	 
	res= USART_ReceiveData(USART1);
	 
	switch(res)
	{
		case '1': LED0 = 1 ;LED1 = 1 ;break ; //开灯
		case '2': LED0 = 0 ;LED1 = 0 ;break ; //关灯
		case '3': Servo_out(); break ; //打开舵机
		case '4': Servo_in();break ; //关闭舵机
		case '5': fengshan = 1 ; break ; //打开风扇
		case '6': fengshan = 0 ;break ; //关闭风扇
		case '7': alarmFlag = 1 ;BEEP=1;delay_ms(2500);BEEP=0;  break ; //关闭报警灯和报警器
		case '8': alarmFlag = 0 ;BEEP=1;delay_ms(2500);BEEP=0;  break ; //关闭报警灯和报警器
  }
 }
}

