#include "delay.h"
#include "sys.h"
#include "oled.h"
#include "timer.h"
#include "dht11.h"
#include "stdio.h"
#include "usart.h" 
#include "esp8266.h"
#include "onenet.h"
#include "BH1750.h"
#include "mq-135.h"
#include "pwm_output.h"
#include "mutiple.h"
#include "key.h"
 
//oled显示的buf
char oledBuf[20];
char oledBuf1[20];
char oledBuf2[20];
char oledBuf3[20];

//数据采集的变量
u8 temp;  //温度    
u8 humi;  //湿度
u8 mq_7;  //一氧化碳
u16 Light_intensity;  //光照度
float mq_135; //空气质量
u8 espfs_flag=0;//开始发送数据标志
//报警相关变量
u8 alarmFlag=0;//报警相开启标志

char PUB_BUF [20] ;//发送数据缓冲区
const char *topics_sub[] = {"/Liluconnection/sub"};//订阅消息名称 发送
unsigned char *dataPtr = NULL;

int main(void)
 {		  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	// 	设置中断级别		
	delay_init();	    	 //延时函数初始化
	Usart1_Init(115200);	// 串口一初始化--ARSPRO
	Usart2_Init(115200);	// 串口二初始化--esp8266
	 Usart3_Init(115200);	 // 串口三初始化--debug
	Adc_Init();
	LED_Init();		  	// 客厅灯初始化
	Beep_Init(); //报警器初始化
	JDQ_Init();
	BH1750_Config_Init();     //BH1750的初始化
	DHT11_Init();	 //温湿度传感器初始化	     
	OLED_Init();		//初始化OLED
	OLED_Clear();//oled清除
	 KEY_Init();//按键初始化
	TIM3_Int_Init(4999,7199);//10Khz的计数频率，计数到5000为500ms 
	SystemInit(); //72M   
	TIM1_PWM_Init(); 
	while(1)
	{ KEY_Scan(0);//按键扫描
			sprintf(oledBuf,"Temp:%d  %d",temp,temalarm);//把数字转化成字符串
			sprintf(oledBuf1,"hum:%d  %d %d",humi,humalarm,lightalarmmin);
			sprintf(oledBuf2,"light:%d %d ",Light_intensity,lightalarmmax);
			sprintf(oledBuf3,"CO:%d  %d",mq_7,coalarm);
			//oled显示
		  OLED_ShowString(0,0,(u8 *)oledBuf,16); 	
			OLED_ShowString(0,2,(u8 *)oledBuf1,16); 	
			OLED_ShowString(0,4,(u8 *)oledBuf2,16); 
			OLED_ShowString(0,6,(u8 *)oledBuf3,16);			
	//按键按下开始连网
		if(esp_flag==1){
		//蜂鸣器鸣叫1s
		BEEP=1;	
		delay_ms(1000);
		BEEP=0;
	  ESP8266_Init();					//初始化ESP8266
	  while(OneNet_DevLink())			//接入onenet
	  delay_ms(250);
  	OneNet_Subscribe(topics_sub, 1);//订阅消息
    delay_ms(180);   //等待测量结束延时180ms，保证通讯   
	  esp_flag=0;
	  espfs_flag=1;
	  LED1 =1;//连接成功led1灯亮
	}		
		if(oleddisplay_flag==1)//每2秒获取信息
		{
			//读取温湿度数据
			DHT11_Read_Data(&temp,&humi);
			//读取光照度
			Light_intensity = bh_data_read() * 4 / 1.2;
			//读取mq135		
			mq_7 = Get_Mq_135();
      
			//信息超过阈值报警
      if(temp>temalarm||humi>humalarm||Light_intensity>lightalarmmax||mq_7>coalarm||Light_intensity<lightalarmmin)
				{
					if(Light_intensity>lightalarmmax)	{Servo_out();LED0=0;}//光强超过最大值打开风扇
					else {	Servo_in();}
					if(Light_intensity<lightalarmmin)	{LED0=1;}//光强低于最小值开灯
          if(mq_7>coalarm)		{	fengshan=1;}//co浓度超过阈值，打开风扇
					else {	fengshan=0;}
			if( alarmFlag==1)//判断警报是否打开
				{
			BEEP=1;
					delay_ms(100);
					BEEP=0;
								}						
			} 
      else BEEP=0; 				
			oleddisplay_flag=0;
				OLED_Clear();//oled清屏	
			}
		if(espfs_flag==1)		//已连网发送数据
			{
				if(espsb_flag==1)//发送数据间隔12s
		{
			int led =GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_8);//获取当前灯状态值
			int fe = GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_11);//获取当前风扇状态值
			int cl = chuanglian_falg;//获取当前风扇状态值
			int  bp =GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_3);//获取当前蜂鸣器状态值
			int  alarm=alarmFlag;//获取当前警报状态值
			sprintf(PUB_BUF,"{\"hum\":%d,\"temp\":%d,\"light\":%d,\"mq_7\":%d,\"led\":%d,\"fengshan\":%d,\"chuangliang\":%d,\"alarm\":%d,\"beep\":%d}",
			humi,temp,Light_intensity,mq_7,led,fe,cl,alarm,bp);//把数字转化成字符串
			OneNet_Publish("/Liluconnection/pub", PUB_BUF);//推送信息
			ESP8266_Clear();//清除数据
			espsb_flag=0;
			timer3=0;		
		}
		
		dataPtr = ESP8266_GetIPD(3);//获取平台发送数据
		if(dataPtr != NULL)
			OneNet_RevPro(dataPtr);//对数据进行解包
		 delay_ms(10);		
		
	}
}
 }

